use auto
go

create table test1
(fname varchar (50))

insert into test1
values ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
go 1000



use Auto2
go

create table test1
(fname varchar (50))

insert into test1
values ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
go 1000